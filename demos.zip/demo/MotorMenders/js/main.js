(function ($) {
    "use strict";

    // Spinner
    var spinner = function () {
        setTimeout(function () {
            if ($('#spinner').length > 0) {
                $('#spinner').removeClass('show');
            }
        }, 1);
    };
    spinner();


    // Initiate the wowjs
    new WOW().init();


    // Sticky Navbar
    $(window).scroll(function () {
        if ($(this).scrollTop() > 300) {
            $('.sticky-top').css('top', '0px');
        } else {
            $('.sticky-top').css('top', '-100px');
        }
    });


    // Dropdown on mouse hover
    const $dropdown = $(".dropdown");
    const $dropdownToggle = $(".dropdown-toggle");
    const $dropdownMenu = $(".dropdown-menu");
    const showClass = "show";

    $(window).on("load resize", function () {
        if (this.matchMedia("(min-width: 992px)").matches) {
            $dropdown.hover(
                function () {
                    const $this = $(this);
                    $this.addClass(showClass);
                    $this.find($dropdownToggle).attr("aria-expanded", "true");
                    $this.find($dropdownMenu).addClass(showClass);
                },
                function () {
                    const $this = $(this);
                    $this.removeClass(showClass);
                    $this.find($dropdownToggle).attr("aria-expanded", "false");
                    $this.find($dropdownMenu).removeClass(showClass);
                }
            );
        } else {
            $dropdown.off("mouseenter mouseleave");
        }
    });


    // Back to top button
    $(window).scroll(function () {
        if ($(this).scrollTop() > 300) {
            $('.back-to-top').fadeIn('slow');
        } else {
            $('.back-to-top').fadeOut('slow');
        }
    });
    $('.back-to-top').click(function () {
        $('html, body').animate({ scrollTop: 0 }, 1500, 'easeInOutExpo');
        return false;
    });


    // Facts counter
    $('[data-toggle="counter-up"]').counterUp({
        delay: 10,
        time: 2000
    });


    // Date and time picker
    $('.date').datetimepicker({
        format: 'L'
    });
    $('.time').datetimepicker({
        format: 'LT'
    });


    // Testimonials carousel
    $(".testimonial-carousel").owlCarousel({
        autoplay: true,
        smartSpeed: 1000,
        center: true,
        margin: 25,
        dots: true,
        loop: true,
        nav: false,
        responsive: {
            0: {
                items: 1
            },
            768: {
                items: 2
            },
            992: {
                items: 3
            }
        }
    });

})(jQuery);

// Form submit
// Get a reference to the form and the thanks message
const form = document.getElementById('booking-form');
const thanksMessage = document.getElementById('thanks-message');

// Add a submit event listener to the form
form.addEventListener('submit', function (event) {
    // Prevent the default form submission behavior
    event.preventDefault();

    // Hide the form
    form.style.display = 'none';

    // Display the thanks message
    thanksMessage.style.display = 'block';

    // Reset the form after 5 seconds
    setTimeout(function () {
        form.style.display = 'block';
        thanksMessage.style.display = 'none';
    }, 5000);
});


// Subscribe Btn
// Get references to the input, button, and message elements
const emailInput = document.getElementById('email-input');
const signupButton = document.getElementById('signup-button');
const thanksMessageSubscribe = document.getElementById('thanks-message-subscribe');

// Add a click event listener to the "Sign Up" button
signupButton.addEventListener('click', function () {
    // Get the user's email from the input
    const userEmail = emailInput.value;

    // Check if the email is not empty
    if (userEmail.trim() !== '') {
        // Hide the input and button
        emailInput.style.display = 'none';
        signupButton.style.display = 'none';

        // Show the thanks message
        thanksMessageSubscribe.style.display = 'block';

        // Reset the form after 3 seconds
        setTimeout(function () {
            emailInput.style.display = 'block';
            signupButton.style.display = 'block';
            thanksMessageSubscribe.style.display = 'none';
            // Clear the input field
            emailInput.value = '';
        }, 3000);
    }
});
